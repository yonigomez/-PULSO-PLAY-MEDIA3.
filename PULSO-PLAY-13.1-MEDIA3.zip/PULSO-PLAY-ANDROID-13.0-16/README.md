# PULSO PLAY Android 13.1 — Media3 único

Esta versión utiliza **AndroidX Media3 ExoPlayer como único motor nativo** para Android, Android TV y Google TV. No incluye LibVLC ni dependencias VLC.

## Qué incluye
- WebView para conservar la interfaz web alojada en el servidor configurado por el usuario.
- Puente JavaScript `PulsoAndroid.openPlayer(url)` para abrir el reproductor nativo.
- Media3 ExoPlayer con módulos HLS y DASH.
- Controles de reproducción, pantalla completa y soporte de navegación por control remoto mediante `PlayerView`.
- Registro de formato, resolución, FPS, decodificador, cuadros descartados y errores en Logcat.
- Reintentos limitados ante errores de reproducción.
- Workflow de GitHub Actions que compila el proyecto real, sin borrar ni regenerar la carpeta `app`.

## Requisitos
- JDK 17
- Gradle 8.7
- Android SDK 35

## Compilar
Desde la raíz del proyecto:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Integración web
La aplicación web debe llamar a `window.PulsoAndroid.openPlayer(url)` cuando el usuario selecciona un canal. La URL debe ser absoluta y comenzar con `http://` o `https://`.

El interceptor de `MainActivity` también intenta interceptar `window.playChannel(ch)` y toma `ch.sources[0].play_url`, `ch.sources[0].url` o `ch.url`.

Si el sitio utiliza otro nombre de función o una estructura distinta para los canales, habrá que adaptar ese puente al `app.js` real del servidor.

## Importante sobre compatibilidad
Media3 puede reproducir HLS y DASH cuando el stream y el dispositivo son compatibles. La compatibilidad final depende del códec, perfil, nivel, resolución, audio, DRM, encabezados y capacidades de decodificación del televisor. Los reintentos no pueden corregir una señal mal formada ni un códec no soportado.
