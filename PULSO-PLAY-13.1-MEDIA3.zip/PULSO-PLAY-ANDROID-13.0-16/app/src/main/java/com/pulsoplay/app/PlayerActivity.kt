package com.pulsoplay.app

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@UnstableApi
class PlayerActivity : Activity() {

    companion object {
        private const val TAG = "PulsoPlayPlayer"
        private const val MIN_BUFFER_MS = 5_000
        private const val MAX_BUFFER_MS = 50_000
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private var retryCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()

        val videoUrl = intent.getStringExtra("VIDEO_URL")?.trim()
        if (videoUrl.isNullOrBlank() || !isHttpUrl(videoUrl)) {
            Toast.makeText(this, "URL de video no válida", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            keepScreenOn = true
        }
        progressBar = ProgressBar(this).apply {
            visibility = View.VISIBLE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.CENTER
            )
        }
        statusText = TextView(this).apply {
            setTextColor(android.graphics.Color.WHITE)
            textSize = 12f
            setPadding(18, 10, 18, 10)
            setBackgroundColor(0x99000000.toInt())
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
            )
        }
        root.addView(playerView)
        root.addView(progressBar)
        root.addView(statusText)
        setContentView(root)

        createPlayer(videoUrl)
    }

    private fun createPlayer(url: String) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("PULSO-PLAY/13.1 (Android Media3)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(MIN_BUFFER_MS, MAX_BUFFER_MS, 1_500, 3_000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(httpFactory)

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .build().also { exo ->
                exo.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                exo.addListener(playerListener)
                exo.addAnalyticsListener(analyticsListener)
                playerView.player = exo
                exo.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
                exo.prepare()
                exo.playWhenReady = true
            }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> {
                    progressBar.visibility = View.VISIBLE
                    statusText.visibility = View.GONE
                }
                Player.STATE_READY -> {
                    progressBar.visibility = View.GONE
                    statusText.visibility = View.GONE
                }
                Player.STATE_ENDED, Player.STATE_IDLE -> progressBar.visibility = View.GONE
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            progressBar.visibility = View.GONE
            Log.e(TAG, "Error de reproducción: code=${error.errorCodeName}; cause=${error.cause}", error)
            statusText.text = "Error de reproducción: ${error.errorCodeName}"
            statusText.visibility = View.VISIBLE
            if (retryCount < 2) {
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ recoverPlayback() }, 1_500)
            } else {
                Toast.makeText(this@PlayerActivity, "No se pudo reproducir esta señal. Revisá la compatibilidad del canal.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val analyticsListener = object : AnalyticsListener {
        override fun onVideoInputFormatChanged(
            eventTime: AnalyticsListener.EventTime,
            format: androidx.media3.common.Format,
            decoderReuseEvaluation: androidx.media3.exoplayer.DecoderReuseEvaluation?
        ) {
            Log.i(TAG, "Video: ${format.width}x${format.height}, ${format.frameRate} FPS, mime=${format.sampleMimeType}, codecs=${format.codecs}")
        }

        override fun onVideoDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            Log.i(TAG, "Decodificador de video: $decoderName; inicialización=${initializationDurationMs}ms")
        }

        override fun onDroppedVideoFrames(
            eventTime: AnalyticsListener.EventTime,
            droppedFrames: Int,
            elapsedMs: Long
        ) {
            Log.w(TAG, "Cuadros de video descartados: $droppedFrames en ${elapsedMs}ms")
        }

        override fun onVideoCodecError(eventTime: AnalyticsListener.EventTime, videoCodecError: Exception) {
            Log.e(TAG, "Error del códec de video", videoCodecError)
        }
    }

    private fun recoverPlayback() {
        val p = player ?: return
        if (retryCount >= 2) return
        retryCount++
        val item = p.currentMediaItem ?: return
        val currentPosition = p.currentPosition
        Log.w(TAG, "Recuperación $retryCount/2 en posición $currentPosition")
        p.setMediaItem(item, currentPosition)
        p.prepare()
        p.playWhenReady = true
    }

    private fun isHttpUrl(value: String): Boolean =
        value.startsWith("https://", ignoreCase = true) || value.startsWith("http://", ignoreCase = true)

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                )
        }
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onStart() {
        super.onStart()
        if (::playerView.isInitialized) player?.playWhenReady = true
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    private fun releasePlayer() {
        if (::playerView.isInitialized) playerView.player = null
        player?.removeListener(playerListener)
        player?.release()
        player = null
    }
}
