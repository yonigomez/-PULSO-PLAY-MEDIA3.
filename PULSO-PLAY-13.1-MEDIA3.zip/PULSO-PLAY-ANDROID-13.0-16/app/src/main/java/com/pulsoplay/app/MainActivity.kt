package com.pulsoplay.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("pulso_play_prefs", Context.MODE_PRIVATE)

        val rootLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#08090C"))
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#08090C"))
        }

        configureWebView()

        // Botón de ajuste de URL de servidor
        val configBtn = ImageButton(this).apply {
            val size = (36 * resources.displayMetrics.density).toInt()
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                setMargins(0, 0, 24, 24)
            }
            setBackgroundColor(Color.parseColor("#8012141C"))
            setImageResource(android.R.drawable.ic_menu_preferences)
            setColorFilter(Color.parseColor("#06B6D4"))
            alpha = 0.4f
            setOnClickListener { showServerUrlDialog() }
        }

        rootLayout.addView(webView)
        rootLayout.addView(configBtn)
        setContentView(rootLayout)

        val savedUrl = prefs.getString("server_url", null)
        if (savedUrl.isNullOrBlank()) {
            showServerUrlDialog()
        } else {
            loadServer(savedUrl)
        }
    }

    private fun configureWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.userAgentString = s.userAgentString + " PulsoPlayAndroidApp/13.1"

        webView.addJavascriptInterface(AndroidBridge(), "PulsoAndroid")
        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectPlayerHook()
            }
        }
    }

    // Inyecta el interceptor para reproducir siempre en ExoPlayer nativo
    private fun injectPlayerHook() {
        val hookJs = """
            (function() {
                if (window.__pulsoHookInjected) return;
                window.__pulsoHookInjected = true;

                const origPlayChannel = window.playChannel;
                window.playChannel = function(ch) {
                    try {
                        let streamUrl = '';
                        if (ch && ch.sources && ch.sources.length > 0) {
                            streamUrl = ch.sources[0].play_url || ch.sources[0].url || '';
                        } else if (ch && ch.url) {
                            streamUrl = ch.url;
                        }

                        if (streamUrl && window.PulsoAndroid) {
                            if (streamUrl.startsWith('/')) {
                                streamUrl = window.location.origin + streamUrl;
                            }
                            window.PulsoAndroid.openPlayer(streamUrl);
                            return;
                        }
                    } catch (e) {
                        console.error('Error ExoPlayer Hook:', e);
                    }
                    if (origPlayChannel) {
                        origPlayChannel(ch);
                    }
                };
            })();
        """.trimIndent()

        webView.evaluateJavascript(hookJs, null)
    }

    private fun showServerUrlDialog() {
        val current = prefs.getString("server_url", "http://") ?: "http://"
        val input = EditText(this).apply {
            setText(current)
            setSelection(text.length)
            hint = "http://tu-servidor:7070"
        }

        AlertDialog.Builder(this)
            .setTitle("Servidor PULSO PLAY")
            .setMessage("Ingresá la dirección IP o dominio de tu servidor:")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Conectar") { _, _ ->
                var url = input.text.toString().trim()
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "http://$url"
                }
                prefs.edit().putString("server_url", url).apply()
                loadServer(url)
            }
            .show()
    }

    private fun loadServer(url: String) {
        webView.loadUrl(url)
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openPlayer(url: String) {
            val cleanUrl = url.trim()
            if (!(cleanUrl.startsWith("https://", true) || cleanUrl.startsWith("http://", true))) {
                runOnUiThread {
                    android.widget.Toast.makeText(this@MainActivity, "Enlace de reproducción no válido", android.widget.Toast.LENGTH_SHORT).show()
                }
                return
            }
            runOnUiThread {
                val intent = Intent(this@MainActivity, PlayerActivity::class.java).apply {
                    putExtra("VIDEO_URL", cleanUrl)
                }
                startActivity(intent)
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
